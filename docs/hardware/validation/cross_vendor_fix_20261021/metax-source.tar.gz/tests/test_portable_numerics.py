import pytest
import torch
import torch.nn.functional as F

from up.accelerator import configure_accelerator, BackendConfigurationError, CapabilityError
from up.accelerator.numerics import PortableNumerics


@pytest.fixture(autouse=True)
def restore_runtime():
    configure_accelerator(backend="cpu", reset=True)
    yield
    configure_accelerator(backend="cpu", reset=True)


def test_native_profile_does_not_enter_pytorch_modes():
    from torch.overrides import _get_current_function_mode
    from torch.utils._python_dispatch import _get_current_dispatch_mode
    before = (_get_current_function_mode(), _get_current_dispatch_mode(), torch.backends.mha.get_fastpath_enabled())
    provider = configure_accelerator(backend="nvidia", reset=True)
    assert provider.numerics_state()["profile"] == "native"
    assert before == (_get_current_function_mode(), _get_current_dispatch_mode(), torch.backends.mha.get_fastpath_enabled())


def test_portable_profile_reset_restores_modes_and_mha_policy():
    from torch.overrides import _get_current_function_mode
    from torch.utils._python_dispatch import _get_current_dispatch_mode
    original = torch.backends.mha.get_fastpath_enabled()
    provider = configure_accelerator({"runtime": {"accelerator": {"backend": "metax", "numerics": "portable_v1"}}}, reset=True)
    assert _get_current_function_mode() is provider._numerics
    assert _get_current_dispatch_mode() is provider._numerics.random_mode
    assert not torch.backends.mha.get_fastpath_enabled()
    configure_accelerator(backend="cpu", reset=True)
    assert _get_current_function_mode() is None and _get_current_dispatch_mode() is None
    assert torch.backends.mha.get_fastpath_enabled() == original


def test_invalid_profile_and_unsupported_device_fail_explicitly():
    with pytest.raises(BackendConfigurationError, match="Unknown numerical profile"):
        configure_accelerator({"runtime": {"accelerator": {"backend": "cpu", "numerics": "unknown"}}}, reset=True)
    with pytest.raises(CapabilityError, match="CUDA-shaped"):
        configure_accelerator({"runtime": {"accelerator": {"backend": "cpu", "numerics": "portable_v1"}}}, reset=True)


def test_portable_state_is_versioned_and_restores_native_rng_atomically(monkeypatch):
    native = torch.arange(40, dtype=torch.uint8)
    observed = []
    monkeypatch.setattr(torch.cuda, "get_rng_state", lambda: native.clone())
    monkeypatch.setattr(torch.cuda, "set_rng_state", lambda value: observed.append(value.clone()))
    provider = configure_accelerator({"runtime": {"accelerator": {"backend": "metax", "numerics": "portable_v1"}}}, reset=True)
    provider._numerics.reseed(123)
    provider._numerics.offset = 2 ** 32 + 7
    state = provider.get_rng_state()
    provider._numerics.reseed(456)
    provider.set_rng_state(state)
    assert provider.numerics_state()["seed"] == 123 and provider.numerics_state()["offset"] == 2 ** 32 + 7
    assert torch.equal(observed[-1], native)
    with pytest.raises(BackendConfigurationError, match="do not mix"):
        provider.set_rng_state(native)
    with pytest.raises(CapabilityError, match="autocast"):
        provider.autocast()


@pytest.mark.parametrize("kind", ["linear", "conv", "layer_norm", "batch_norm", "silu"])
def test_widened_forward_and_backward_preserve_fp32_contract(kind):
    g = torch.Generator().manual_seed(11)
    x = torch.randn(2, 3, 4, 4, generator=g, requires_grad=True)
    weight = torch.randn(3, generator=g, requires_grad=True)
    bias = torch.randn(3, generator=g, requires_grad=True)
    running = torch.zeros(3), torch.ones(3)
    if kind == "linear":
        fn = lambda v,w,b:F.linear(v,w.expand(4,3),None)
        x = x.transpose(1,3).contiguous().detach().requires_grad_()
    elif kind == "conv":
        fn = lambda v,w,b:F.conv2d(v,w.reshape(1,3,1,1),None)
    elif kind == "layer_norm":
        fn = lambda v,w,b:F.layer_norm(v,(4,4))
    elif kind == "batch_norm":
        fn = lambda v,w,b:F.batch_norm(v,running[0],running[1],w,b,training=True)
    else:
        fn = lambda v,w,b:F.silu(v)
    with PortableNumerics(device_type="cpu"):
        output = fn(x,weight,bias)
        loss = output.sum()
    gradients = torch.autograd.grad(loss,(x,weight,bias),allow_unused=True)
    assert output.dtype == torch.float32
    assert all(t is None or t.dtype == torch.float32 and torch.isfinite(t).all() for t in gradients)
    assert torch.isfinite(output).all()


def test_nested_mode_cannot_be_popped_by_reset():
    from torch.overrides import TorchFunctionMode
    class Outer(TorchFunctionMode):
        def __torch_function__(self, function, types, args=(), kwargs=None):
            return function(*args, **(kwargs or {}))
    configure_accelerator({"runtime": {"accelerator": {"backend": "metax", "numerics": "portable_v1"}}}, reset=True)
    with Outer():
        with pytest.raises(BackendConfigurationError, match="nested PyTorch modes"):
            configure_accelerator(backend="cpu", reset=True)


def test_portable_semantic_operations_are_shared_but_native_owner_is_unchanged():
    from up.accelerator import ops
    config = {"runtime": {"accelerator": {"backend": "nvidia", "numerics": "portable_v1"}}}
    provider = configure_accelerator(config, reset=True)
    assert provider.capabilities()["operations"]["naive_nms"]["owner"] == "portable_v1"
    assert torch.equal(ops.torchvision_nms(torch.tensor([[0.,0.,3.,3.],[0.,0.,3.,3.]]),
                                         torch.ones(2),.5), torch.tensor([0]))
    provider = configure_accelerator(backend="nvidia", reset=True)
    assert provider.capabilities()["operations"]["naive_nms"]["owner"] == "nvidia"


def test_batch_norm_running_state_and_gradients_match_widened_reference():
    g = torch.Generator().manual_seed(11)
    values = [torch.randn(3,4,5,6,generator=g), torch.randn(4,generator=g), torch.randn(4,generator=g)]
    inputs = [[value.clone().requires_grad_() for value in values] for _ in range(2)]
    stats = [(torch.zeros(4), torch.ones(4)), (torch.zeros(4,dtype=torch.float64), torch.ones(4,dtype=torch.float64))]
    upstream = torch.randn(3,4,5,6,generator=g)
    with PortableNumerics(device_type="cpu"):
        actual = F.batch_norm(inputs[0][0],*stats[0],*inputs[0][1:],training=True,momentum=.2,eps=1e-4)
    expected = F.batch_norm(inputs[1][0].double(),*stats[1],*[t.double() for t in inputs[1][1:]],
                           training=True,momentum=.2,eps=1e-4).float()
    assert torch.equal(actual,expected)
    a, b = [torch.autograd.grad(output, state, upstream) for output,state in zip((actual,expected),inputs)]
    assert all(torch.equal(x,y) for x,y in zip(a,b))
    assert all(torch.equal(x,y.float()) for x,y in zip(*stats))


def test_inplace_silu_preserves_alias_and_gradient():
    source = torch.tensor([-2.,.3,4.],requires_grad=True)
    value = source * 1
    with PortableNumerics(device_type="cpu"):
        result = F.silu(value,inplace=True)
    assert result is value
    result.sum().backward()
    reference = source.detach().double().requires_grad_()
    F.silu(reference).sum().backward()
    assert torch.equal(source.grad,reference.grad.float())


def test_nested_dispatch_mode_cannot_be_popped_by_reset():
    from torch.utils._python_dispatch import TorchDispatchMode
    class Other(TorchDispatchMode):
        def __torch_dispatch__(self,function,types,args=(),kwargs=None):
            return function(*args,**(kwargs or {}))
    configure_accelerator({"runtime": {"accelerator": {"backend": "metax", "numerics": "portable_v1"}}},reset=True)
    with Other():
        with pytest.raises(BackendConfigurationError,match="nested PyTorch dispatch modes"):
            configure_accelerator(backend="cpu",reset=True)


def test_new_plan_keeps_existing_models_budgets_seeds_and_threshold():
    import json
    from pathlib import Path
    root = Path(__file__).resolve().parents[1] / "docs/hardware/validation"
    old = json.loads((root / "cross_vendor_diagnosis_20261021/plan.json").read_text())
    new = json.loads((root / "cross_vendor_fix_20261021/plan.json").read_text())
    assert old["models"] == new["models"]
    assert old["equivalence"] == new["equivalence"]
    assert new["numerical_profile"] == "portable_v1"
