# Standard Library
import os
import bisect
import json
import copy
from collections import Counter, OrderedDict

# Import from third library
import numpy as np
import cv2
import matplotlib.pyplot as plt
import pandas
import yaml
from prettytable import PrettyTable

from up.utils.general.log_helper import default_logger as logger
from up.utils.general.yaml_loader import IncludeLoader
from up.utils.general.registry_factory import EVALUATOR_REGISTRY
from up.utils.general.petrel_helper import PetrelHelper
from up.data.metrics.base_evaluator import Evaluator, Metric
from up.data.image_reader import build_image_reader
from up.utils.general.vis_helper import vis_bad_case_with_text
from .eval_utils import get_miss_rate_multi_size, get_scale_factor

__all__ = ['MREvaluator']


class CustomEvaluator(Evaluator):
    def __init__(self, gt_file, num_classes, iou_thresh=0.5, ign_iou_thresh=0.5, metrics_csv='metrics.csv', label_mapping=None, ignore_mode=0, cross_cfg=None):  # noqa
        super(CustomEvaluator, self).__init__()
        self.gt_file = gt_file
        self.iou_thresh = iou_thresh
        self.ign_iou_thresh = ign_iou_thresh
        self.num_classes = num_classes
        self.gt_loaded = False
        self.metrics_csv = metrics_csv
        self.label_mapping = label_mapping
        self.class_from = {}
        self.cross_cfg = cross_cfg
        if self.cross_cfg is not None:
            self.label_mapping = self.cross_cfg.get('label_mapping', [[]])
        if self.label_mapping is not None:
            for idx, label_map in enumerate(self.label_mapping):
                for label in label_map:
                    self.class_from[label] = [idx]
        else:
            self.label_mapping = [[]]
            if not isinstance(gt_file, list):
                gt_file = [gt_file]
            for label in range(1, self.num_classes):
                self.class_from[label] = list(range(len(gt_file)))
        self.ignore_mode = ignore_mode

    def set_label_mapping(self, data, idx):
        if len(self.label_mapping[0]) == 0:
            return data
        instances = data.get('instances', [])
        for instance in instances:
            if instance.get("is_ignored", False):
                if self.ignore_mode == 1:
                    pass
                else:
                    continue
            instance["label"] = self.label_mapping[idx][int(instance["label"] - 1)]
        return data

    def load_gts(self, gt_files, min_size, max_size, gt_rescale, metric_level, for_check=False):
        # maintain a dict to store original img information
        # key is image dir,value is image_height,image_width,instances
        original_gt = {}
        gts = {
            'bbox_num': Counter(),
            'gt_num': Counter(),
            'image_num': 0,
            'image_scale': {},
            'image_ids': list()
        }
        if not isinstance(gt_files, list):
            gt_files = [gt_files]
        for gt_file_idx, gt_file in enumerate(gt_files):
            gt_img_ids = set()
            with PetrelHelper.open(gt_file) as f:
                for i, line in enumerate(f):
                    img = json.loads(line)
                    if self.label_mapping is not None:
                        img = self.set_label_mapping(img, gt_file_idx)
                    image_id = img['filename']
                    original_gt[img['filename']] = copy.deepcopy(img)
                    gt_img_ids.add(image_id)
                    image_height = img['image_height']
                    image_width = img['image_width']
                    gts['image_num'] += 1
                    gts['image_scale'][image_id] = get_scale_factor(min_size, max_size, image_height,
                                                                    image_width) if gt_rescale else 1.0
                    for idx, instance in enumerate(img.get('instances', [])):
                        instance['detected'] = False
                        # remember the original index within an image of annoated format so
                        # we can recover from distributed format into original format
                        is_ignore = instance.get('is_ignored', False)
                        instance['local_index'] = idx
                        label = instance.get('label', 0)
                        # ingore mode
                        # 0 indicates all classes share ignore region, label is set to -1
                        # 1 indicates different classes different ignore region, ignore label must be provided
                        # 2 indicates we ingore all ignore regions
                        if is_ignore and self.ignore_mode == 0:
                            label = -1
                        if for_check:
                            box_by_img = gts.setdefault(image_id, {'gts': []})
                        else:
                            box_by_label = gts.setdefault(label, {})
                            box_by_img = box_by_label.setdefault(image_id, {'gts': []})
                        gt_by_img = box_by_img['gts']
                        gts['bbox_num'][label] += 1
                        if not is_ignore:
                            bbox = instance['bbox']
                            rescale_factor = gts['image_scale'][image_id]
                            if (bbox[3] - bbox[1]) * rescale_factor >= metric_level and (
                                    bbox[2] - bbox[0]) * rescale_factor >= metric_level:
                                gt_by_img.append(instance)
                                gts['gt_num'][label] += 1
                            else:
                                ign_by_img = box_by_img.setdefault('ignores', [])
                                ign_by_img.append(instance)
                        else:
                            ign_by_img = box_by_img.setdefault('ignores', [])
                            ign_by_img.append(instance)
                gts['image_ids'].append(gt_img_ids)
        return gts, original_gt

    def reset_detected_flag(self):
        for cls in range(1, self.num_classes):
            if cls in self.gts.keys():
                for img_id, gts in self.gts[cls].items():
                    for instance in gts['gts']:
                        instance['detected'] = False
                        instance['detected_score'] = -1

    def load_dts(self, res_file, res=None):
        dts = {}
        if res is None:
            logger.info(f'loading res from {res_file}')
            with open(res_file, 'r') as f:
                for line in f:
                    dt = json.loads(line)
                    dt_by_label = dts.setdefault(dt['label'], [])
                    dt_by_label.append(dt)
        else:
            for device_res in res:
                for lines in device_res:
                    for line in lines:
                        dt_by_label = dts.setdefault(line['label'], [])
                        dt_by_label.append(line)
        return dts

    def calIoU(self, b1, b2):
        area1 = (b1[:, 2] - b1[:, 0]) * (b1[:, 3] - b1[:, 1])
        area2 = (b2[:, 2] - b2[:, 0]) * (b2[:, 3] - b2[:, 1])
        inter_xmin = np.maximum(b1[:, 0].reshape(-1, 1), b2[:, 0].reshape(1, -1))
        inter_ymin = np.maximum(b1[:, 1].reshape(-1, 1), b2[:, 1].reshape(1, -1))
        inter_xmax = np.minimum(b1[:, 2].reshape(-1, 1), b2[:, 2].reshape(1, -1))
        inter_ymax = np.minimum(b1[:, 3].reshape(-1, 1), b2[:, 3].reshape(1, -1))
        inter_h = np.maximum(inter_xmax - inter_xmin, 0)
        inter_w = np.maximum(inter_ymax - inter_ymin, 0)
        inter_area = inter_h * inter_w
        union_area1 = area1.reshape(-1, 1) + area2.reshape(1, -1)
        union_area2 = (union_area1 - inter_area)
        return inter_area / np.maximum(union_area2, 1)

    def calIof(self, b, g):
        area1 = (b[:, 2] - b[:, 0]) * (b[:, 3] - b[:, 1])
        inter_xmin = np.maximum(b[:, 0].reshape(-1, 1), g[:, 0].reshape(1, -1))
        inter_ymin = np.maximum(b[:, 1].reshape(-1, 1), g[:, 1].reshape(1, -1))
        inter_xmax = np.minimum(b[:, 2].reshape(-1, 1), g[:, 2].reshape(1, -1))
        inter_ymax = np.minimum(b[:, 3].reshape(-1, 1), g[:, 3].reshape(1, -1))
        inter_h = np.maximum(inter_xmax - inter_xmin, 0)
        inter_w = np.maximum(inter_ymax - inter_ymin, 0)
        inter_area = inter_h * inter_w
        return inter_area / np.maximum(area1, 1)

    def get_cur_dts(self, dts_cls, gts_img_id_set):
        """ Only the detecton results of images on which class c is annotated are kept.
        This is necessary for federated datasets evaluation
        """
        cur_gt_dts = []
        for _, dt in enumerate(dts_cls):
            if dt['image_id'] in gts_img_id_set:
                cur_gt_dts.append(dt)
        return cur_gt_dts

    def get_cur_gt(self, gts_cls, gts_img_id_set):
        """ Only the ground truthes of images on which class c is annotated are kept.
        This is necessary for federated datasets evaluation
        """
        cur_gt = {}
        for img_id, gt in gts_cls.items():
            if img_id in gts_img_id_set:
                cur_gt[img_id] = gt
        return cur_gt

    def get_cls_tp_fp(self, dts_cls, gts_cls, image_scale, iou_thresh, ign_iou_thresh):
        """
        Arguments:
            dts_cls (list): det results of one specific class.
            gts_cls (dict): ground truthes bboxes of all images for one specific class
        """
        fps, tps = np.zeros((len(dts_cls))), np.zeros((len(dts_cls)))
        matched_gt_minsize = np.ones((len(dts_cls))) * -1
        for i, dt in enumerate(dts_cls):
            img_id = dt['image_id']
            dt_bbox = dt['bbox']
            m_iou, m_gt, m_iof = -1, -1, -1
            if img_id in gts_cls:
                gts = gts_cls[img_id]
                gt_bboxes = [g['bbox'] for g in gts['gts']]
                ign_bboxes = [g['bbox'] for g in gts['ignores']] if 'ignores' in gts else []
                m_iou, m_gt, m_iof = \
                    self.match(dt_bbox, gt_bboxes, ign_bboxes)
            if m_iou >= self.iou_thresh:
                if not gts['gts'][m_gt]['detected']:
                    tps[i] = 1
                    fps[i] = 0
                    gts['gts'][m_gt]['detected'] = True
                    gts['gts'][m_gt]['detected_score'] = dt['score']
                    m_gt_bboxes = gt_bboxes[m_gt]
                    box_w = m_gt_bboxes[2] - m_gt_bboxes[0]
                    box_h = m_gt_bboxes[3] - m_gt_bboxes[1]
                    matched_gt_minsize[i] = np.minimum(box_w, box_h)
                    matched_gt_minsize[i] *= image_scale[img_id]

                else:
                    fps[i] = 1
                    tps[i] = 0
            else:
                fps[i] = 1
                tps[i] = 0
            if self.ignore_mode == 0:
                # if we share ignore region between classes, some images may only have ignore region
                # and the m_iof will be set to -1, this is wrong, so we need re calculate m_iof of ignore region

                igs_cls = self.gts.get(-1, {})
                if img_id in igs_cls:
                    igs = igs_cls.get(img_id, {})
                    ign_bboxes = [g['bbox'] for g in igs['ignores']] if 'ignores' in igs else []
                    m_iof = self.match_ig(dt_bbox, ign_bboxes)
            if self.ignore_mode == 2:
                m_iof = -1
            if fps[i] == 1 and m_iof >= self.ign_iou_thresh:
                fps[i] = 0
                tps[i] = 0

        return np.array(tps), np.array(fps), np.array(matched_gt_minsize)

    def match_ig(self, dt, igns):
        dt = np.array(dt).reshape(-1, 4)
        if len(igns) > 0:
            igns = np.array(igns)
            iofs = self.calIof(dt, igns).reshape(-1)
            maxiof = np.max(iofs)
        else:
            maxiof = 0
        return maxiof

    def match(self, dt, gts, igns):
        dt = np.array(dt).reshape(-1, 4)
        gts = np.array(gts)
        if len(gts) > 0:
            ious = self.calIoU(dt, gts).reshape(-1)
            matched_gt = ious.argmax()
            matched_iou = ious[matched_gt]
        else:
            matched_iou = -1
            matched_gt = -1
        if len(igns) > 0:
            igns = np.array(igns)
            iofs = self.calIof(dt, igns).reshape(-1)
            maxiof = np.max(iofs)
        else:
            maxiof = 0
        return matched_iou, matched_gt, maxiof

    def get_cls_tp_fp_mask(self, class_i, dts_cls, gts_cls):
        fps, tps = np.zeros((len(dts_cls))), np.zeros((len(dts_cls)))
        for i, dt in enumerate(dts_cls):
            img_id = dt['image_id']
            dt_mask = dt['segmentation']
            m_iou, m_gt = -1, -1
            if img_id in gts_cls:
                gts = gts_cls[img_id]
                gt_masks = [g['mask'] for g in gts['gts']]
                m_iou, m_gt = self.match_mask(dt, dt_mask, gt_masks, gts['gts'])
            if m_iou >= self.iou_thresh:
                if not gts['gts'][m_gt]['detected']:
                    tps[i] = 1
                    fps[i] = 0
                    gts['gts'][m_gt]['detected'] = True
                    gts['gts'][m_gt]['detected_score'] = dt['score']
                else:
                    fps[i] = 1
                    tps[i] = 0
            else:
                fps[i] = 1
                tps[i] = 0
        return np.array(tps), np.array(fps)


@EVALUATOR_REGISTRY.register('MR')
class MREvaluator(CustomEvaluator):
    """Calculate mAP&MR@FPPI for custom dataset"""

    def __init__(self,
                 gt_file,
                 num_classes,
                 iou_thresh,
                 class_names=None,
                 fppi=np.array([0.1, 0.5, 1]),
                 metrics_csv='metrics.csv',
                 label_mapping=None,
                 analysis_json='bad_case.jsonl',
                 bad_case_analyser=None,
                 img_root=None,
                 vis_mode=None,
                 image_reader=None,
                 ignore_mode=0,
                 ign_iou_thresh=0.5,
                 iou_types=['bbox'],
                 eval_class_idxs=[],
                 cross_cfg=None,
                 gt_rescale=True,
                 watch_scale=[],
                 max_size=1333,
                 metric_level=0,
                 scales=[800],
                 ignore_class_idxs=[],
                 cmp_key=None,
                 label_check=None):

        super(MREvaluator, self).__init__(gt_file,
                                          num_classes,
                                          iou_thresh,
                                          metrics_csv=metrics_csv,
                                          label_mapping=label_mapping,
                                          ignore_mode=ignore_mode,
                                          ign_iou_thresh=ign_iou_thresh,
                                          cross_cfg=cross_cfg)

        if len(eval_class_idxs) == 0:
            eval_class_idxs = list(range(1, num_classes))
        self.eval_class_idxs = eval_class_idxs
        self.eval_without_ignore_class_idxs = [idx for idx in self.eval_class_idxs if idx not in ignore_class_idxs]
        self.image_reader = image_reader
        self.fppi = np.array(fppi)
        self.class_names = class_names
        self.metrics_csv = metrics_csv
        if self.class_names is None:
            self.class_names = list(range(1, num_classes))
        self.init_vis(bad_case_analyser, analysis_json, img_root, vis_mode)
        self.iou_types = iou_types
        self.watch_scale = watch_scale
        self.gt_rescale = gt_rescale
        assert self.gt_rescale in [True, False], f'gt_rescale wrong: {self.gt_rescale}'
        self.metric_level = metric_level
        self.max_size = max_size
        assert len(scales) == 1, 'scales {}, but only single scale is allowed during evaluating'.format(scales)
        self.min_size = scales[0]
        self.cmp_key = cmp_key
        self.label_check = label_check

    def init_vis(self, bad_case_analyser, analysis_json, img_root, vis_mode):
        # init for bad case analysis
        if self.image_reader is not None:
            self.image_reader = build_image_reader(self.image_reader)
            self.img_root = '/'  # assert
        if bad_case_analyser:
            self.bad_case_analyzer_is_on = True
            # if vis_mode is not None:
            #     assert img_root is not None and os.path.exists(img_root)
            mode, thresh = bad_case_analyser.split('_')
            assert mode in ['manual', 'fppi']
            if mode == 'fppi':
                assert float(thresh) in self.fppi
        else:
            self.bad_case_analyzer_is_on = False
        self.analysis_json = analysis_json
        self.img_root = img_root
        self.bad_case_analyser = bad_case_analyser
        assert vis_mode in [None, 'all', 'fp', 'fn']
        self.vis_missing = self.vis_mistake = False
        if vis_mode in ['all', 'fn']:
            self.vis_missing = True
        if vis_mode in ['all', 'fp']:
            self.vis_mistake = True

    def get_miss_rate(self, tp, fp, scores, image_num, gt_num, drec, prec, return_index=False):
        """
        input: accumulated tps & fps
        len(tp) == len(fp) == len(scores) == len(box)
        """
        N = len(self.fppi)
        maxfps = self.fppi * image_num
        mrs = np.zeros(N)
        fppi_scores = np.zeros(N)
        fppi_ap = np.zeros(N)

        indices = []
        for i, f in enumerate(maxfps):
            idxs = np.where(fp > f)[0]
            if len(idxs) > 0:
                idx = idxs[0]  # the last fp@fppi
            else:
                idx = -1  # no fps, tp[-1]==gt_num
            indices.append(idx)
            mrs[i] = 1 - tp[idx] / gt_num
            fppi_scores[i] = scores[idx]
            fppi_ap[i] = np.sum(drec[:idx] * prec[:idx])
        if return_index:
            return mrs, fppi_scores, fppi_ap, indices
        else:
            return mrs, fppi_scores, fppi_ap

    def _np_fmt(self, x):
        s = "["
        for i in list(x):
            s += " {:.4f}".format(i)
        s += " ]"
        return s

    def export(self, output, ap, max_recall, fppi_miss, fppi_scores,
               recalls_at_fppi, precisions_at_fppi, fppi_ap):

        def compute_f1_score(recall, precision):
            return 2 * recall * precision / np.maximum(1, recall + precision)

        f1_score_at_fppi = compute_f1_score(recalls_at_fppi, precisions_at_fppi)

        fg_class_names = copy.deepcopy(self.class_names)
        if self.num_classes == len(self.class_names):
            fg_class_names = fg_class_names[1:]

        assert len(fg_class_names) == self.num_classes - 1

        csv_metrics = OrderedDict()
        csv_metrics['Class'] = fg_class_names
        csv_metrics['AP'] = ap[1:].tolist()
        csv_metrics['Recall'] = max_recall[1:].tolist()
        for idx, fppi in enumerate(self.fppi):
            csv_metrics['MR@FPPI={:.3f}'.format(fppi)] = fppi_miss[1:, idx].tolist()
        for idx, fppi in enumerate(self.fppi):
            csv_metrics['Score@FPPI={:.3f}'.format(fppi)] = fppi_scores[1:, idx].tolist()
        for idx, fppi in enumerate(self.fppi):
            csv_metrics['Rec@FPPI={:.3f}'.format(fppi)] = recalls_at_fppi[1:, idx].tolist()
        for idx, fppi in enumerate(self.fppi):
            csv_metrics['Prec@FPPI={:.3f}'.format(fppi)] = precisions_at_fppi[1:, idx].tolist()
        for idx, fppi in enumerate(self.fppi):
            csv_metrics['F1@FPPI={:.3f}'.format(fppi)] = f1_score_at_fppi[1:, idx].tolist()
        for idx, fppi in enumerate(self.fppi):
            csv_metrics['Ap@FPPI={:.3f}'.format(fppi)] = fppi_ap[1:, idx].tolist()

        # Summary
        mAP = np.mean(ap[1:]).tolist()
        m_rec = np.mean(max_recall[1:]).tolist()
        m_fppi_miss = np.mean(fppi_miss[1:], axis=0).tolist()
        m_score_at_fppi = np.mean(fppi_scores[1:], axis=0).tolist()
        m_rec_at_fppi = np.mean(recalls_at_fppi[1:], axis=0).tolist()
        m_prec_at_fppi = np.mean(precisions_at_fppi[1:], axis=0).tolist()
        m_f1_score_at_fppi = np.mean(f1_score_at_fppi[1:], axis=0).tolist()
        m_ap_at_fppi = np.mean(fppi_ap[1:], axis=0).tolist()
        # Summary without ignore
        mAP_no_ign = np.mean(ap[self.eval_without_ignore_class_idxs]).tolist()
        m_rec_ign = np.mean(max_recall[self.eval_without_ignore_class_idxs]).tolist()
        m_fppi_miss_ign = np.mean(fppi_miss[self.eval_without_ignore_class_idxs], axis=0).tolist()
        m_score_at_fppi_ign = np.mean(fppi_scores[self.eval_without_ignore_class_idxs], axis=0).tolist()
        m_rec_at_fppi_ign = np.mean(recalls_at_fppi[self.eval_without_ignore_class_idxs], axis=0).tolist()
        m_prec_at_fppi_ign = np.mean(precisions_at_fppi[self.eval_without_ignore_class_idxs], axis=0).tolist()
        m_f1_score_at_fppi_ign = np.mean(f1_score_at_fppi[self.eval_without_ignore_class_idxs], axis=0).tolist()
        m_ap_at_fppi_ign = np.mean(fppi_ap[self.eval_without_ignore_class_idxs], axis=0).tolist()

        csv_metrics['Class'].append('Mean')
        csv_metrics['AP'].append(mAP)
        csv_metrics['Recall'].append(m_rec)
        for fppi, mr, score, recall, precision, f1_score, ap_f in zip(self.fppi, m_fppi_miss, m_score_at_fppi,
                                                                      m_rec_at_fppi, m_prec_at_fppi,
                                                                      m_f1_score_at_fppi, m_ap_at_fppi):

            csv_metrics['MR@FPPI={:.3f}'.format(fppi)].append(mr)
            csv_metrics['Score@FPPI={:.3f}'.format(fppi)].append(score)
            csv_metrics['Rec@FPPI={:.3f}'.format(fppi)].append(recall)
            csv_metrics['Prec@FPPI={:.3f}'.format(fppi)].append(precision)
            csv_metrics['F1@FPPI={:.3f}'.format(fppi)].append(f1_score)
            csv_metrics['Ap@FPPI={:.3f}'.format(fppi)].append(ap_f)
        # add results for without ignore
        csv_metrics['Class'].append('Mean_focus')
        csv_metrics['AP'].append(mAP_no_ign)
        csv_metrics['Recall'].append(m_rec_ign)
        for fppi, mr, score, recall, precision, f1_score, ap_f in zip(self.fppi, m_fppi_miss_ign, m_score_at_fppi_ign,
                                                                      m_rec_at_fppi_ign, m_prec_at_fppi_ign,
                                                                      m_f1_score_at_fppi_ign, m_ap_at_fppi_ign):
            csv_metrics['MR@FPPI={:.3f}'.format(fppi)].append(mr)
            csv_metrics['Score@FPPI={:.3f}'.format(fppi)].append(score)
            csv_metrics['Rec@FPPI={:.3f}'.format(fppi)].append(recall)
            csv_metrics['Prec@FPPI={:.3f}'.format(fppi)].append(precision)
            csv_metrics['F1@FPPI={:.3f}'.format(fppi)].append(f1_score)
            csv_metrics['Ap@FPPI={:.3f}'.format(fppi)].append(ap_f)

        csv_metrics_table = pandas.DataFrame(csv_metrics)
        csv_metrics_table.to_csv(output, index=False, float_format='%.4f')
        return output, csv_metrics_table, csv_metrics

    def export_bad_case(self, original_data):
        with open(self.analysis_json, 'w') as fd:
            for image_id, res in original_data.items():
                fd.write(json.dumps(res, ensure_ascii=False) + '\n')

    def visualize_bad_case(self, analyze_res, class_names, ext='jpg', dpi=200):
        mix_root = 'vis_dt_bad_case'
        if not os.path.exists(mix_root):
            os.mkdir(mix_root)
        for ind, img_res in analyze_res.items():
            missing_list = img_res.get('missing_instances', [])
            predict_list = img_res.get('predict_instances', [])
            with_missing = len(missing_list) > 0
            with_mistake = not all(x['is_right'] for x in predict_list)
            if self.vis_missing and self.vis_mistake and (with_missing or with_mistake):
                pass
            elif self.vis_missing and with_missing:
                pass
            elif self.vis_mistake and with_mistake:
                pass
            else:
                continue
            logger.info('visualzing bad case for image {}'.format(ind))
            if self.image_reader is not None:
                img = self.image_reader(ind)
            else:
                img_path = os.path.join(self.img_root, ind)
                img = cv2.imread(img_path)
                img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
            instances = img_res['instances']
            fig = vis_bad_case_with_text(img, instances, missing_list, predict_list, mix_root, class_names)
            im_name = ind.split('/')[-1].split('.')[0]
            output_name = os.path.basename(im_name) + '.' + ext
            fig.savefig(os.path.join(mix_root, '{}'.format(output_name)))
            plt.close('all')

    def analyze_bad_case(self, original_gt, results, tps, fps, gts, score_fppi):
        """Analyze bad for one specific class
        Args:
          original_gt -> dict: key is image_id, value is original annotated format for each image
          results -> list: detections results, with 'bbox', 'score'
          fps, tps -> list: same length with 'results', indicating the coresponding detection results
          is false positive or true positive
          gts -> dict: key is image_id, value is list of ground truth instances
          score_fppi -> list: same length with self.fppi
        """
        # First of all, guess score threshold
        mode, thresh = self.bad_case_analyser.split('_')
        thresh = float(thresh)
        assert mode in ['manual', 'fppi']
        assert len(score_fppi) == len(self.fppi)
        if mode == 'fppi':
            assert thresh in self.fppi
            index = bisect.bisect(self.fppi, thresh)
            score_thresh = score_fppi[index]
        else:
            score_thresh = thresh

        # analyze fase positives and true positives in the context that the bbox score threshold = 'score_thresh'
        for dt, fp, tp in zip(results, fps, tps):
            if dt['score'] <= score_thresh:
                # actually, we can break
                continue
            dt['is_right'] = dt['is_ignored'] = False
            if fp > 0:
                dt['is_right'] = False
            elif tp > 0:
                dt['is_right'] = True
            else:
                dt['is_ignored'] = True
            image_id = dt['image_id']
            pred_list = original_gt[image_id].setdefault('predict_instances', [])
            pred_list.append(dt)

        # analyze false negative (missing ground truthes)
        for image_id, gts_and_ignores in gts.items():
            missing_list = original_gt[image_id].setdefault('missing_instances', [])
            gt_list = gts_and_ignores['gts']
            # we ignore gts_and_ignores['ignores']
            for gt in gt_list:
                if not gt['detected'] or gt['detected_score'] < score_thresh:
                    missing_list.append(gt['local_index'])

    def pretty_print(self, metric_table, pr_prec_fppi=False):
        columns = list(metric_table.columns)

        if pr_prec_fppi:
            for col in columns[1:]:
                if not (col.startswith('Rec@') or col.startswith('Prec@') or col.startswith('F1@')
                        or col.startswith('Ap@')):
                    del metric_table[col]
        else:
            for col in columns[1:]:
                if col.startswith('Rec@') or col.startswith('Prec@') or col.startswith('F1@') or col.startswith('Ap@'):
                    del metric_table[col]

        table = PrettyTable()
        table.field_names = list(metric_table.columns)
        table.align = 'l'
        table.float_format = '.4'
        table.title = 'Evaluation Results with FPPI={}'.format(self.fppi)
        for index, row in metric_table.iterrows():
            table.add_row(list(row))
        logger.info('\n{}'.format(table))

    def get_topk_fp_images(self, res_file, res):
        score_thresh = self.label_check.get('score_thresh', 0.5)
        check_num = self.label_check.get('check_num', 25)
        for itype in self.iou_types:
            self.gts, original_gt = self.load_gts(self.gt_file, self.min_size,
                                                  self.max_size, self.gt_rescale, self.metric_level, True)
            dts = {}
            if res is None:
                logger.info(f'loading res from {res_file}')
                with open(res_file, 'r') as f:
                    for line in f:
                        dt = json.loads(line)
                        if dt['score'] > score_thresh:
                            dt_by_filename = dts.setdefault(dt['image_id'], [])
                            dt_by_filename.append({'bbox': dt['bbox'], 'score': dt['score'],
                                                   'label': dt['label'], 'image_id': dt['image_id']})
                        else:
                            continue
            else:
                for device_res in res:
                    for lines in device_res:
                        for line in lines:
                            if line['score'] > score_thresh:
                                dt_by_filename = dts.setdefault(line['image_id'], [])
                                dt_by_filename.append({'bbox': line['bbox'], 'score': line['score'],
                                                       'label': line['label'], 'image_id': line['image_id']})
                            else:
                                continue
            fp_list = []
            for idx, image_id in enumerate(dts):
                results_i = dts[image_id]
                cur_gt = {}
                cur_gt[image_id] = self.gts.get(image_id, {})
                if cur_gt[image_id]:
                    if itype == 'bbox':
                        tps, fps, matched_gt_minsize = self.get_cls_tp_fp(results_i, cur_gt, self.gts['image_scale'],
                                                                          self.iou_thresh, self.ign_iou_thresh)
                    fp_mean = fps.sum() / len(fps)
                else:
                    fp_mean = 1
                fp_list.append({'image_id': image_id, 'fp_mean': fp_mean})
            fp_list_sorted = sorted(fp_list, key=lambda x: x['fp_mean'], reverse=True)
            image_unlabeled = fp_list_sorted[: check_num]
            pwd = os.getcwd()
            txt_path = self.label_check.get('results_dir', '')
            txt_name = self.label_check.get('filename', 'unlabeled')
            absolute_path = os.path.join(pwd, txt_path)
            os.makedirs(absolute_path, exist_ok=True)
            check_file = os.path.join(absolute_path, '{}.txt'.format(txt_name))
            with open(check_file, mode='w', encoding='utf-8') as fb:
                for idx, image_id in enumerate(image_unlabeled):
                    fb.write(str(image_unlabeled[idx]['image_id']) + '\n')

    def eval(self, res_file, res=None):
        metric_res = Metric({})
        for itype in self.iou_types:
            num_mean_cls = 0
            if not self.gt_loaded:
                self.gts, original_gt = self.load_gts(self.gt_file, self.min_size,
                                                      self.max_size, self.gt_rescale, self.metric_level)
                self.gt_loaded = True
            else:
                self.reset_detected_flag()
            dts = self.load_dts(res_file, res)
            ap = np.zeros(self.num_classes)
            max_recall = np.zeros(self.num_classes)
            fppi_miss = np.zeros([self.num_classes, len(self.fppi)])
            fppi_scores = np.zeros([self.num_classes, len(self.fppi)])
            fppi_ap = np.zeros([self.num_classes, len(self.fppi)])
            recalls_at_fppi = np.zeros([self.num_classes, len(self.fppi)])
            precisions_at_fppi = np.zeros([self.num_classes, len(self.fppi)])
            for class_i in self.eval_class_idxs:  # range(1, self.num_classes):
                sum_dt = self.gts['bbox_num'][class_i]
                sum_gt = self.gts['gt_num'][class_i]
                results_i = dts.get(class_i, [])
                results_i = sorted(results_i, key=lambda x: -x['score'])
                class_from = self.class_from.get(class_i, [0])
                gts_img_id_set = set()
                for data_idx in class_from:
                    gts_img_id_set = gts_img_id_set.union(self.gts['image_ids'][data_idx])
                if class_i not in self.gts:
                    self.gts[class_i] = {}
                cur_gt = self.get_cur_gt(self.gts[class_i], gts_img_id_set)
                # get the detection results from federated dataset for class_i
                results_i = self.get_cur_dts(results_i, gts_img_id_set)
                logger.info('sum_gt vs sum_dt: {} vs {}'.format(sum_gt, len(results_i)))
                if sum_gt > 0:
                    num_mean_cls += 1
                if sum_dt == 0 or len(results_i) == 0:
                    # ap[class_i] = 0.0
                    # max_recall[class_i] = 0.0
                    continue

                if itype == 'bbox':
                    tps, fps, matched_gt_minsize = self.get_cls_tp_fp(results_i, cur_gt, self.gts['image_scale'],
                                                                      self.iou_thresh, self.ign_iou_thresh)
                drec = tps / max(1, sum_gt)
                tp = np.cumsum(tps)
                fp = np.cumsum(fps)
                rec = tp / sum_gt
                prec = tp / np.maximum(tp + fp, 1)
                for v in range(len(prec) - 2, -1, -1):
                    prec[v] = max(prec[v], prec[v + 1])
                scores = [x['score'] for x in results_i]
                image_num = len(gts_img_id_set)
                mrs, s_fppi, ap_fppi, indices = self.get_miss_rate(tp, fp, scores, image_num, sum_gt, drec,
                                                                   prec, return_index=True)
                watch_scale = self.watch_scale
                if len(watch_scale) > 0:
                    multi_size_metrics = get_miss_rate_multi_size(tp, fp, scores, self.gts, class_i,
                                                                  matched_gt_minsize, watch_scale, self.fppi)
                    for k, v in multi_size_metrics.items():
                        logger.info("{}:\t{}*{}".format(self.class_names[class_i - 1], k, v))
                ap[class_i] = np.sum(drec * prec)
                max_recall[class_i] = np.max(rec)
                fppi_miss[class_i] = mrs
                fppi_scores[class_i] = s_fppi
                fppi_ap[class_i] = ap_fppi
                recalls_at_fppi[class_i] = rec[np.array(indices)]
                precisions_at_fppi[class_i] = prec[np.array(indices)]

                if self.bad_case_analyzer_is_on:
                    self.analyze_bad_case(original_gt, results_i, tps, fps, cur_gt, s_fppi)

            mAP = np.sum(ap[1:]) / num_mean_cls

            _, metric_table, csv_metrics = self.export(
                self.metrics_csv, ap, max_recall, fppi_miss, fppi_scores, recalls_at_fppi, precisions_at_fppi, fppi_ap)
            self.pretty_print(copy.deepcopy(metric_table))
            self.pretty_print(copy.deepcopy(metric_table), pr_prec_fppi=True)

            metric_name = '{}_mAP:{}'.format(itype, self.iou_thresh)
            csv_metrics.update({metric_name: mAP})
            metric_res.update(csv_metrics)
            if self.cmp_key and metric_res.get(self.cmp_key, False):
                metric_name = self.cmp_key
            metric_res.set_cmp_key(metric_name)

            if self.bad_case_analyzer_is_on:
                self.export_bad_case(original_gt)
                if self.vis_missing or self.vis_mistake:
                    self.visualize_bad_case(original_gt, self.class_names)
        if isinstance(self.label_check, dict):
            self.get_topk_fp_images(res_file, res)
        return metric_res

    @staticmethod
    def add_subparser(name, subparsers):
        subparser = subparsers.add_parser(name, help='subcommand for CustomDataset of mAP metric')
        subparser.add_argument('--gt_file', required=True, help='annotation file')
        subparser.add_argument('--res_file', required=True, help='results file of detection')
        subparser.add_argument('--num_classes',
                               type=int,
                               default=None,
                               help='number of classes including __background__ class')
        subparser.add_argument('--class_names',
                               type=lambda x: x.split(','),
                               default=None,
                               help='names of classes including __background__ class')
        subparser.add_argument('--iou_thresh',
                               type=float,
                               default=0.5,
                               help='iou thresh to classify true positives & false postitives')
        subparser.add_argument('--ign_iou_thresh',
                               type=float,
                               default=0.5,
                               help='ig iou thresh to ignore false postitives')
        subparser.add_argument('--metrics_csv',
                               type=str,
                               default='metrics.csv',
                               help='file to save evaluation metrics')
        subparser.add_argument('--img_root',
                               type=str,
                               default='None',
                               help='directory of images used to evaluate, only used for visualization')
        subparser.add_argument('--bad_case_analyser',
                               type=str,
                               default='manual_0.5',
                               help='choice of criterion for analysing bad case, format:{manual or fppi}_{[score]}')
        subparser.add_argument('--vis_mode',
                               type=str,
                               default=None,
                               choices=['all', 'fp', 'fn', None],
                               help='visualize fase negatives or fase positive or all')
        subparser.add_argument('--eval_class_idxs',
                               type=lambda x: list(map(int, x.split(','))),
                               default=[],
                               help='eval subset of all classes, 1,3,4'
                               )
        subparser.add_argument('--ignore_mode',
                               type=int,
                               default=0,
                               help='ignore mode, default as 0')
        subparser.add_argument('--config', type=str, default='', help='training config for eval')
        subparser.add_argument('--iou_types',
                               type=list,
                               default=['bbox'],
                               help='iou type to select eval mode')

        return subparser

    @classmethod
    def get_classes(self, gt_file):
        all_classes = set()

        with PetrelHelper.open(gt_file) as f:
            for line in f:
                data = json.loads(line)
                labels = set([ins['label'] for ins in data['instances'] if ins['label'] > 0])
                all_classes |= labels
        all_classes = [0] + sorted(list(all_classes))
        class_names = [str(_) for _ in all_classes]
        print('class_names:{}'.format(class_names))
        return class_names

    @classmethod
    def from_args(cls, args):
        if args.config != '':   # load from training config
            cfg = yaml.load(open(args.config, 'r'), Loader=IncludeLoader)
            eval_kwargs = cfg['dataset']['test']['dataset']['kwargs']['evaluator']['kwargs']
            eval_kwargs['metrics_csv'] = args.metrics_csv
            return cls(**eval_kwargs)
        if args.num_classes is None:
            args.class_names = cls.get_classes(args.gt_file)
            args.num_classes = len(args.class_names)
        return cls(args.gt_file,
                   args.num_classes,
                   args.iou_thresh,
                   args.class_names,
                   metrics_csv=args.metrics_csv,
                   ignore_mode=args.ignore_mode,
                   eval_class_idxs=args.eval_class_idxs,
                   ign_iou_thresh=args.ign_iou_thresh,
                   iou_types=args.iou_types,)
